package com.kimetsu.cobbleaddon;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Khung addon cho Cobblemon (Fabric 1.21.1). Chua dung API Cobblemon nao:
 * code dung Cobblemon chi duoc viet sau khi doc ten class that tu jar (probe workflow).
 */
public class CobbleAddon implements ModInitializer {
    public static final String MOD_ID = "cobbleaddon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Item TRAINER_BADGE;

    @Override
    public void onInitialize() {
        TRAINER_BADGE = Registry.register(BuiltInRegistries.ITEM,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "trainer_badge"),
                new Item(new Item.Properties().stacksTo(16)));
        LOGGER.info("Cobble Addon da khoi dong");
    }
}
